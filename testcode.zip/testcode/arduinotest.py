# Importing Libraries
import serial
import time

arduino = serial.Serial(port='COM3', baudrate=115200, timeout=.1)


def write_read(x):
    arduino.write(x)
    time.sleep(0.05)
    data = arduino.readline()
    data = str(data, 'UTF-8')
    return data


while True:
    value = write_read(5)
    print(value)  # printing the value
