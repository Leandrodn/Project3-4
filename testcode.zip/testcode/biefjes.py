while True:
    amount = int(input("How much would you like to withdraw today?"))
    if amount % 10 == 0:
        notes50 = amount // 50
        notes20 = ((amount - (notes50 * 50)) // 20)
        notes10 = ((amount - (notes50 * 50) - (notes20 * 20)) // 10)
        print("briefjes van 50 ", notes50)
        print("briefjes van 20 ", notes20)
        print("briefjes van 10 ", notes10)
    else:
        print("kan niet hoer")
