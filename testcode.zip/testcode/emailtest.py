import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.pdfgen.canvas import Canvas
from datetime import datetime

now = datetime.now()

# dd/mm/YY H:M:S
date_str = now.strftime("%d/%m/%Y")
time_str = now.strftime("%H:%M")
print("date and time =", date_str, time_str)

canvas = Canvas("Transactiebon.pdf", pagesize=A4)
canvas.drawImage("logov2.png", 2.5 * inch, 9.25 * inch)
canvas.drawString(1 * inch, 9 * inch, '-----------------------------------------------------------------------------'
                                         '------------------------------------')
canvas.drawString(1 * inch, 8.75 * inch, 'Datum:' + date_str + '                                                           '
                                                            '                              Tijd: ' + time_str)
canvas.drawString(1 * inch, 8.5 * inch, '-----------------------------------------------------------------------------'
                                         '------------------------------------')
canvas.drawString(1 * inch, 8.25 * inch, 'Automaat: 88')
canvas.drawString(1 * inch, 8 * inch, 'Transactie #: XXXX')
canvas.drawString(1 * inch, 7.75 * inch, 'Rekening #: XXX-XX12-34')
canvas.drawString(1 * inch, 7.5 * inch, 'Pas #: XXX')
canvas.drawString(1 * inch, 7.25 * inch, 'Bedrag: XXX,-')
canvas.drawString(1 * inch, 7 * inch, '-----------------------------------------------------------------------------'
                                         '------------------------------------')
canvas.drawString(1 * inch, 6.75 * inch, 'Bedankt voor het gebruiken van de services van ABN-MANBRO')
canvas.drawString(1 * inch, 6.5 * inch, 'GRAAG TOT ZIENS!')
canvas.save()

email_user = 'ABNMANBRO@gmail.com'
email_password = 'Timmerman?88'
# email_send = '1003440@hr.nl'
# email_send1 = 'd.hofman@hr.nl'
# email_send2 = 't.de.ruiter@hr.nl'

subject = 'Transactiebon'

msg = MIMEMultipart()
msg['From'] = email_user
msg['To'] = email_send
msg['Subject'] = subject

body = 'Beste klant,\ndankuwel voor transactie bij ABN-MANBRO.\nUw digitale transactie bon vindt u in de bijlage.\nNog een fijne dag en graag tot ziens!\n\nMet vriendelijke groet,\nABN-MANBRO'
msg.attach(MIMEText(body,'plain'))

filename='Transactiebon.pdf'
attachment  =open(filename,'rb')

part = MIMEBase('application','octet-stream')
part.set_payload((attachment).read())
encoders.encode_base64(part)
part.add_header('Content-Disposition',"attachment; filename= "+filename)

msg.attach(part)
text = msg.as_string()
server = smtplib.SMTP('smtp.gmail.com',587)
server.starttls()
server.login(email_user,email_password)


server.sendmail(email_user,email_send1,text)
server.sendmail(email_user,email_send2,text)


server.quit()


